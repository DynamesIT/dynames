# DYNAMES member portal (STAGING v0.3)

Questo modulo è una **preparazione tecnica** del Registro membri per Supabase. Non è stato creato alcun database esterno.

`member-portal.html` incorpora il tema istituzionale e carica `member-portal.css`, `workspace-config.js`, Supabase JS v2 (CDN) e `member-portal.js`.

Per default `workspace-config.js` contiene valori vuoti e `enableRegistration:false`, quindi il portale mostra esplicitamente **non collegato**. Il suo uso con `file://` è intenzionalmente bloccato. Per collaudo il portale deve essere pubblicato su HTTPS (o localhost in ambiente di sviluppo).

**Attivazione:** dopo installazione migrazioni e verifiche di RLS, completare `workspace-config.js` con `url`, `publishableKey`, `privacyNoticeUrl`, `privacyVersion`, quindi impostare `enableRegistration:true`. Non inserire mai una secret key nel browser.

Il modulo si connette alle tabelle `member_profiles`, `member_applications`, `members`, `topics`, `member_topics`, `contribution_areas`, `member_contributions`, `access_grants`, `member_documents`. Le RPC sono `save_my_profile` (migrazione 003) e `review_application` (migrazione 001). La directory membri completa e gli incarichi restano una fase successiva.

La versione v0.3 aggiunge conferma password in fase di registrazione, recupero password e un controllo SQL sulle email effettivamente verificate. Anche queste funzioni restano disabilitate fino all’attivazione della configurazione.
