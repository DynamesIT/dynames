# DYNAMES Workspace — mappatura interfaccia → database

| Campo / funzione nel prototipo `workspace-index.html` | Destinazione nel modello reale |
|---|---|
| Identità / credenziali email | Supabase Auth (`auth.users`), email verificata; **non** password nella tabella `members` |
| Nome e cognome | `member_profiles.first_name`, `.last_name` |
| Ente e posizione | `member_profiles.organization`, `.professional_position` |
| Email di contatto / telefono | `member_profiles.contact_email`, `.phone` |
| Presentazione | `member_profiles.biography` |
| Aree di interesse (multiple) | `topics` + `member_topics` |
| Contributi desiderati (multiple) | `contribution_areas` + `member_contributions` |
| Candidatura e approvazione | `member_applications`; revisione `public.review_application` solo Super Admin |
| Membro approvato | `members` + grant globale `member` in `access_grants` |
| Foto e CV | Oggetti nel bucket privato `dynames-member-files`; riferimenti in `member_documents` |
| Ruolo Super Admin e accessi | `access_grants` con ambiti global/function/project |
| Log decisioni e permessi | `audit_log` |

**Non inclusi in questa prima migrazione:** anagrafica di membri senza credenziali, incarichi organizzativi (`positions`,`appointments`), gruppi (`projects`,`project_members`), LoE e timeline. Saranno estensioni successive con migrazioni distinte. I ruoli `function_lead` e `project_lead` sono predisposti ma non devono essere assegnati finché non esisteranno le corrispondenti tabelle di ambito.

## Flusso applicativo previsto

1. `auth.signUp` con conferma obbligatoria dell'email; eventuale controllo anti-bot/rate limiting a livello applicativo.
2. Sessione autenticata: `member_profiles` (insert owner), poi `member_topics` e `member_contributions`.
3. Upload tramite Storage API su path `<auth.uid()>/photo/<uuid>.jpg` e `<auth.uid()>/cv/<uuid>.pdf` (file privati). Metadata in `member_documents`; trattare upload e metadata come due passaggi con pulizia dei file orfani.
4. L'utente accetta l'informativa e crea `member_applications` (sola insert; default `pending`). Il campo `privacy_notice_version` è solo registro tecnico: occorre predisporre l'informativa prima di attivare il servizio.
5. Super Admin legge le candidature e chiama `review_application(p_user_id, true/false)`. L'operazione in transazione crea l'iscritto e il grant base soltanto se approvata.
6. Solo Super Admin può aggiungere o revocare grants avanzati. La directory non è leggibile da altri membri nella fase 1, se non per il proprio profilo.

**Importante:** una schermata HTML statica su Google Drive/GitHub non costituisce accesso protetto. Serviranno il frontend con Supabase JS, l'autenticazione, le chiamate database e un hosting capace di gestire correttamente sessioni e redirect. Non inserire `service_role`, `secret key` o password di DB nel JavaScript pubblico.
