# Collaudo autorizzazioni (obbligatorio prima di attivare registrazioni reali)

Questo documento è una checklist di **test ancora da eseguire** su un Supabase di prova. Testare con: anon, candidato A, candidato B, membro approvato e Super Admin.

- [ ] Non autenticato: può leggere solo il catalogo temi/attività; non può leggere persone/candidature/permessi/documenti.
- [ ] Utente A: crea solo il proprio profilo; non può creare o aggiornare il profilo B.
- [ ] Utente A: seleziona più tematiche e le rimuove senza poter modificare quelle di B.
- [ ] Utente A: inserisce una candidatura `pending`; non può inserire `approved` né modificare `status`, `reviewed_by`, `reviewed_at`.
- [ ] Utente A: non può invocare `review_application` per approvare sé stesso o B.
- [ ] Candidato A: non può leggere la candidatura/il CV di B né la directory di altri membri.
- [ ] Super Admin: può leggere candidature e approvare/rifiutare; l'operazione genera `members`, `access_grants` e traccia audit.
- [ ] Dopo l'approvazione, membro base: può leggere solo proprio profilo; non può leggere tutti i profili.
- [ ] Membro base: non può creare `access_grants`, revocare privilegi né inserire direttamente un record in `members`.
- [ ] La revoca del grant `super_admin` impedisce immediatamente ulteriori operazioni amministrative.
- [ ] User A: può caricare in Storage solo sotto `<A>/photo` o `<A>/cv` e non sotto `<B>`.
- [ ] I file con estensioni non ammesse, bucket pubblico, path multipli sono respinti; verificare MIME reale, dimensioni e scanner malware a livello applicativo.
- [ ] A può leggere/eliminare file propri, non file B; Super Admin può leggere file B solo per scopi autorizzati.
- [ ] Il CV non appare in URL pubblici permanenti; URL firmati con scadenza breve.
- [ ] Cambio password, disattivazione utente, cancellazione account e trattamento dei file orfani producono risultati coerenti.
- [ ] Registro audit registra cambio stato, inserimento membro e attribuzione/revoca grant senza registrare dati sensibili.
- [ ] In caso di perdita di tutti i Super Admin esiste procedura documentata di recupero SQL Editor.
- [ ] Revisione GDPR: base giuridica, informativa, foto pubblica separata, retention e diritti interessati.
