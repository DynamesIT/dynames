-- DYNAMES Workspace: candidatura consentita solo con email Auth verificata.
-- Eseguire DOPO 001, 002 e 003, su ambiente TEST e collaudare con utenti distinti.
begin;
create function private.has_confirmed_email()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from auth.users u
    where u.id = (select auth.uid()) and u.email_confirmed_at is not null
  );
$$;
revoke execute on function private.has_confirmed_email() from public, anon, authenticated;
grant execute on function private.has_confirmed_email() to authenticated;
drop policy application_submit on public.member_applications;
create policy application_submit on public.member_applications for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and status = 'pending'
    and (select private.has_confirmed_email())
  );
commit;
