-- DYNAMES Workspace / v0.2: salvataggio atomico del profilo e degli interessi.
-- Eseguire DOPO le migrazioni 001 e 002 in un progetto Supabase di test.
-- Non conferisce alcuna possibilità di approvare candidature o assegnare ruoli.

begin;

create function public.save_my_profile(
  p_first_name text,
  p_last_name text,
  p_contact_email text,
  p_phone text,
  p_organization text,
  p_professional_position text,
  p_biography text,
  p_topics text[],
  p_contributions text[]
)
returns void
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception 'Autenticazione richiesta' using errcode = '42501';
  end if;
  if nullif(btrim(p_first_name),'') is null
     or nullif(btrim(p_last_name),'') is null then
    raise exception 'Nome e cognome obbligatori';
  end if;
  if coalesce(cardinality(p_topics),0) = 0 then
    raise exception 'Selezionare almeno una tematica';
  end if;
  if coalesce(cardinality(p_topics),0) > 10 then
    raise exception 'Numero di tematiche non valido';
  end if;
  if coalesce(cardinality(p_contributions),0) > 4 then
    raise exception 'Numero di contributi non valido';
  end if;
  if exists (select 1 from unnest(p_topics) as topic where topic is null)
    or exists (select 1 from unnest(p_contributions) as c where c is null) then
    raise exception 'Valori nulli non ammessi';
  end if;

  insert into public.member_profiles (
    user_id, first_name, last_name, contact_email, phone,
    organization, professional_position, biography
  ) values (
    v_user_id,btrim(p_first_name),btrim(p_last_name),nullif(btrim(p_contact_email),''),
    nullif(btrim(p_phone),''),nullif(btrim(p_organization),''),
    nullif(btrim(p_professional_position),''),nullif(btrim(p_biography),'')
  )
  on conflict (user_id) do update set
    first_name=excluded.first_name,
    last_name=excluded.last_name,
    contact_email=excluded.contact_email,
    phone=excluded.phone,
    organization=excluded.organization,
    professional_position=excluded.professional_position,
    biography=excluded.biography;

  delete from public.member_topics where user_id=v_user_id;
  insert into public.member_topics (user_id,topic_slug)
    select v_user_id, t.topic
    from (select distinct unnest(p_topics) as topic) t;

  delete from public.member_contributions where user_id=v_user_id;
  insert into public.member_contributions (user_id,area_code)
    select v_user_id,c.code
    from (select distinct unnest(coalesce(p_contributions,array[]::text[])) as code) c;
end;
$$;

revoke execute on function public.save_my_profile(
  text,text,text,text,text,text,text,text[],text[]
) from public,anon,authenticated;
grant execute on function public.save_my_profile(
  text,text,text,text,text,text,text,text[],text[]
) to authenticated;

-- Controllo anche lato database al momento della prima candidatura.
create function private.require_application_topics()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not exists (
    select 1 from public.member_topics where user_id=new.user_id
  ) then
    raise exception 'Prima della candidatura selezionare almeno una tematica';
  end if;
  return new;
end;
$$;
create trigger applications_require_topics
before insert on public.member_applications
for each row execute function private.require_application_topics();
revoke execute on function private.require_application_topics() from public,anon,authenticated;

commit;
