# DYNAMES Workspace · Integrazione Supabase · pacchetto di STAGING v0.3

Data: 1 novembre 2026. **Nessun progetto Supabase creato e nessuna registrazione reale attiva.**

## Struttura proposta su Google Drive

```
dynames-main/
  workspace/
    workspace-index.html               (demo v1.2 esistente: NON modificata)
    portal/
      member-portal.html                (nuovo frontend di staging)
      member-portal.css
      member-portal.js
      workspace-config.js               (configurazione vuota: registrazioni disattivate)
    database/
      supabase/migrations/
        20261101000100_member_registry.sql
        20261101000200_private_storage_policies.sql
        20261101000300_profile_rpc.sql
        20261101000400_confirmed_email_guard.sql
      supabase/tests/001_schema_smoke.sql
      docs/...
```

## Da fare prima di attivare il portale

1. Collegare l'app **Supabase** al proprio account in ChatGPT, oppure creare da dashboard Supabase un progetto **DYNAMES-Workspace-TEST** con regione UE. Preferire proprietà organizzativa della Fondazione / DYNAMES, non credenziali personali di collaboratori.
2. Abilitare MFA per gli amministratori; conferma email obbligatoria; disabilitare accesso anonimo. Limitare gli inviti, rate-limit e prevenzione abusi; configurare email SMTP in produzione.
3. Creare bucket Storage privato `dynames-member-files`: public=false, max 10 MB, content-types jpeg/png/webp/pdf. Non caricare CV reali finché non sono definite scansione malware e retention.
4. Installare le quattro migrazioni **nell'ordine indicato**, inizialmente su un progetto TEST. `001` e `002` provengono dal pacchetto v0.1; `003` aggiunge salvataggio atomico profilo/interessi; `004` richiede email Auth verificata per l’invio della candidatura.
5. Eseguire test RLS con almeno tre utenti distinti (candidato, membro e admin), controlli positivi/negativi, lettura file CV, revoca admin e permessi. La presenza dei file SQL **non** prova che le regole siano state eseguite o verificate.
6. Registrare un primo Super Admin esclusivamente attraverso SQL Editor con account Auth verificato e profilo creato; seguire il README database e rivedere la procedura di bootstrap. Non fare bootstrap da HTML.
7. Approvare l'informativa privacy specifica e pubblicarla su URL HTTPS. Definire titolare, basi giuridiche, retention e accordi con i fornitori.
8. Configurare Auth **Site URL** e redirect consentiti per URL di test del portale su hosting HTTPS; Google Drive non è un server adatto a gestire redirect di produzione, e file:// non supporta il flusso Auth.
9. Aprire `portal/workspace-config.js` e impostare: URL progetto, **publishable key** (non secret!), URL/versione informativa. Solo dopo i test impostare `enableRegistration: true`.
10. Pubblicare su hosting HTTPS di STAGING; verificare il flusso completo. Non inserire link sul menu pubblico né abilitare registrazioni fino al via libera.

## Ruoli e contenuti disponibili ora

- Account con conferma email, conferma password e recupero password; compilazione profilo; selezione multipla delle 10 tematiche; 4 aree di contribuzione.
- Candidatura in attesa di approvazione; solo il Super Admin può approvare o rifiutare.
- Foto e PDF CV privati; sostituzione/rimozione; link temporanei per il titolare; apertura CV per Super Admin.
- Nessun grant `super_admin` automatico; approvazione concede soltanto `member`.
- I dati non sono salvati in Google Drive: collegamento a Supabase viene attivato **soltanto** dopo la configurazione.
- `positions`, `projects`, `loes`, `timeline` rimangono nella demo e richiederanno migrazioni successive.

## Sicurezza e limiti noti

- Questo codice è predisposto per integrazione, **non è un audit di sicurezza né produzione pronta**.
- Fotografie/CV: controlli di estensione/MIME/dimensione nel browser e regole Storage sono preliminari. Occorrono validazione lato server del tipo effettivo, protezione antivirus, prevenzione file orfani e gestione consenso/retention.
- Il ruolo `member` non concede automaticamente di vedere la directory interna.
- Le configurazioni accessibili dal browser possono contenere solo l'URL e la publishable key; non usare secret key o credenziali del database.
- Non collocare foto e CV nell'attuale repository GitHub pubblico o in cartelle Drive condivise senza controllo degli accessi.
- Per continuità delle funzionalità, la demo `workspace-index.html` NON è stata sovrascritta con una versione parzialmente funzionante.

### Riferimenti
- https://supabase.com/docs/guides/database/postgres/row-level-security
- https://supabase.com/docs/guides/auth/passwords
- https://supabase.com/docs/guides/storage/security/access-control
- https://supabase.com/docs/reference/javascript/installing

## Collegamento Supabase: stato del 1 novembre 2026

L'app Supabase non risulta collegata nella sessione corrente. Il progetto remoto non è ancora stato creato da questo assistente, e non è stata eseguita nessuna migrazione su un database reale. **Non** impostare `enableRegistration: true` finché la connessione e i test RLS end-to-end non sono confermati.

**Attivazione della registrazione**: associare progetto Supabase TEST di proprietà dell'organizzazione; impostare URL/chiave pubblica (mai service/secret key); creare bucket privato; aggiungere Site URL e redirect URL; configure email confirmation e SMTP; verificare account separati candidato/membro/admin; MFA admin; e poi abilitare registrazione in un ambiente HTTPS test.

**Importante sulla disponibilità**: questo ZIP in Google Drive è esclusivamente una consegna di file; non equivale al deployment dell'applicazione né alla configurazione del database.
