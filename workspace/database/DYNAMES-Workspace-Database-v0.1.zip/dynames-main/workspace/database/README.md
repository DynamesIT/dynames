# DYNAMES Workspace · Database v0.1 (01 novembre 2026)

**Ambito:** prima migrazione eseguibile per *Member Registry & Access Management*; non è ancora un database distribuito né una registrazione reale attiva.

## File inclusi

- `supabase/migrations/20261101000100_member_registry.sql`: 10 tabelle, seed tematiche, funzioni di approvazione, audit, permessi, RLS.
- `supabase/migrations/20261101000200_private_storage_policies.sql`: RLS sui file foto e CV in Storage.
- `supabase/tests/001_schema_smoke.sql`: verifiche strutturali pgTAP; non sostituiscono i test RLS applicativi.
- `docs/mapping-interfaccia.md`: collegamento con i campi della demo `workspace-index.html`.
- `docs/schema-relazionale.mmd`: diagramma logico.

## Prima di installare

1. Creare un **progetto Supabase di prova** con regione UE, 2FA per gli amministratori e accesso limitato al team.
2. Attivare conferma email in Auth, disabilitare anonymous sign-in, configurare redirect e controllo anti-abuso. I candidati devono verificare l'email prima di poter creare la scheda.
3. Creare in **Storage**, tramite Dashboard/API, il bucket `dynames-member-files` impostato **Private** (`public=false`), max 10 MB, MIME consentiti `image/jpeg,image/png,image/webp,application/pdf`.
4. Verificare che lo schema `private` **non sia esposto** in Data API; non includerlo tra gli schemi esposti.
5. Definire informativa privacy, tempi di conservazione CV, cancellazioni, responsabilità dei trattamenti e accordi con i fornitori.

## Installazione in ambiente di TEST

Da Supabase CLI inizializzata con `supabase init`, collocare le due migrazioni nella cartella `supabase/migrations/` del progetto e avviare `supabase start` / `supabase db reset` in un ambiente isolato, **oppure** eseguirle nell'ordine nel SQL Editor di un progetto di prova, dopo backup. Ogni migrazione va applicata una sola volta.

Lanciare `supabase test db` con estensione `pgtap` disponibile; eseguire anche **test RLS end-to-end di autorizzazione positiva e negativa** prima di considerare il modulo idoneo all'uso reale.

## Primo Super Admin — bootstrap esplicito (solo in ambiente di prova)

Dopo la creazione e verifica email di un account Auth e la compilazione della relativa `member_profiles`, dal **SQL Editor con privilegi amministrativi** (mai dall'HTML):

```sql
-- SOSTITUIRE <USER_UUID> con l'UUID reale del primo account Auth, non un'email.
begin;
insert into public.members(user_id,status) values ('<USER_UUID>'::uuid,'active');
insert into public.access_grants(user_id,role_code,scope_type)
values ('<USER_UUID>'::uuid,'super_admin','global');
commit;
```

**Non inserire** chiavi private nel codice, nel repository pubblico o in Drive. Questo bootstrap non serve se non è stato ancora creato un progetto Supabase.

## Configurazione dei documenti

- Foto: `UUID/photo/file-uuid.jpg|png|webp`, max 5 MB applicativi e vincolo metadati DB.
- CV: `UUID/cv/file-uuid.pdf`, max 10 MB.
- Bucket privato, nessun URL permanente pubblico; lettura autorizzata e preferibilmente URL firmato a breve scadenza.
- Il controllo MIME/estensione e le dimensioni sono *difese iniziali*: il frontend/backend deve validare i contenuti reali e predisporre scansione malware, oltre alla gestione dei file orfani.
- Le operazioni Storage si fanno tramite l'API Storage, **non** con DML direttamente su `storage.objects`.

## Avvertenze

- Non collegare ancora questa migrazione al prototipo `workspace-index.html`: quello è volutamente una demo statica con dati dimostrativi.
- La migrazione **non** crea utenze, non invia inviti, non attiva autenticazione e non pubblica nulla.
- La separazione tra `member_profiles` (autocompilati) e `members` / `access_grants` (amministrati) impedisce di ottenere un ruolo elevato modificando la scheda personale.
- I privilegi di Supabase sono vincolati tramite RLS e GRANT. Sono comunque necessari test di penetrazione, gestione errori, backup, informativa privacy e procedure di recupero amministratore.
- La directory per tutti i membri, gli incarichi e i progetti saranno abilitati in fasi successive con autorizzazioni specifiche.

Riferimenti: https://supabase.com/docs/guides/database/postgres/row-level-security ; https://supabase.com/docs/guides/storage/security/access-control ; https://supabase.com/docs/guides/database/testing
